#ifndef MYSEMAPHORE
#define MYSEMAPHORE

#include "AbstractSemaphore.hpp"

class MySemaphore : public AbstractSemaphore
{
};

#endif
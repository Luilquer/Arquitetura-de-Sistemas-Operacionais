#include <stdio.h>

int main(){
    int x;
    scanf("%d",&x);
    
    //programe aqui suas threads
    
    
    }
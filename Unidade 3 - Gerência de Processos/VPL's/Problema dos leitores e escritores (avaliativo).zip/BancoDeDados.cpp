#include "BancoDeDados.h"

//implemente aqui as funcoes BancoDeDados::read() e BancoDeDados::increment()
